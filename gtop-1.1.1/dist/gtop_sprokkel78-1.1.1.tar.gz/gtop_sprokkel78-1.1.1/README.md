# gtop

A graphical user interface in pygtk for Process and Network overview on Mac mini.
It requires Homebrew, Python3.11 and PyGObject.

